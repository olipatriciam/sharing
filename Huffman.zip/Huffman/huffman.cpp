#include <algorithm>
#include <queue>
#include <deque>
#include <map>
#include <vector>
#include <fstream>
#include <iostream>
#include <string>
#include "nodo.h"

using namespace std;

#include "huffman.h"

huffman::huffman(void)
{
}

huffman::~huffman(void)
{
}

void huffman::Calcular_Frequencia()
{
	fstream file("teste.txt",ios::in | ios::binary);

	char caractere;
	int count = 0;

	string letra;

	while(file.read(&caractere,1))
	{
		letra = caractere;

		tabela[letra]++; //adiciona e conta quantas vezes repete
	}

	file.close();

	// mostrar a frequencia e o caractere
	// e adicionar num vector
	cout<<"o map, que contem a tabela inicial"<< endl;
	map<string, int>::const_iterator i;
	for(i = tabela.begin(); i != tabela.end(); i++){

		cout << i->second << " " << (i->first) << endl;

		struct transforma temp;
		temp.caractere = i->first;
		temp.frequencia = i->second;
		temp.huff = "";
		vetor.push_back(temp);
	}

	// testando como ficou

	cout <<"mostrando o vetor, que irei usar a partir de agora"<<endl;
	for(int i =0; i<vetor.size(); i++){
		cout << vetor[i].frequencia<<" "<< vetor[i].caractere<<" "<< vetor[i].huff << endl;
	}
}

void huffman::Create_binary_tree()
{
	nodo * n;

	for(int i =0; i<vetor.size(); i++){
		n = new nodo;
		n->frequencia = vetor[i].frequencia;
		n->simbol = vetor[i].caractere[0];
		Fila.push( n );
	}

	nodo* interno;

	while(!Fila.empty()){

	// remova os 2 n�s com a menor probabilidade / Frequencia

		nodo* n1;
		nodo* n2;
		n1 = Fila.top();
		Fila.pop();
		n2 = Fila.top();
		Fila.pop();

	//	crie um n� interno com os dois n�s
	//	removidos como filhos. A probabilidade desse
	//	n� � a soma dos dois filhos

		interno = new nodo;
		interno->FilhoD = n1;
		interno->FilhoE = n2;
		interno->frequencia = n1->frequencia + n2->frequencia;

		cout <<"filho direita: "<<interno->FilhoD->simbol<<" filho esquerda: "<<interno->FilhoE->simbol<<" frequencia do interno: "<<interno->frequencia <<endl;

	//	Adicione o novo n� na fila

		Fila.push(interno);

	// terminou???? adiciona a raiz numa variavel

		if(Fila.size() == 1)
		{
			RAIZ = Fila.top();
			Fila.pop();
			break;
		}
	}
}

void huffman::PercorrerArvore(nodo * n, string code) // tentando ver a arvore
{     //  Se o nodo for uma folha, salva o c�digo nele

       if (!n->FilhoE && !n->FilhoD) {
              n->huffcode = code;

			struct transforma temp;
			// poderia colocar o caractere tbm?
			temp.caractere = n->simbol;
			temp.huff = n->huffcode;
			TABELA.push_back(temp);
       }

      // Sen�o, chama fun��o para o filho da direita e coloca o 1 no c�digo (direita � 1)

       else {
              string novoCodeD = code + "1";
              PercorrerArvore(n->FilhoD, novoCodeD);

            //  E faz o mesmo para o filho da esquerda (coloca 0)

              string novoCodeE = code + "0";
              PercorrerArvore(n->FilhoE, novoCodeE);
       }
}



void huffman::Create_new_file_HUF()
{

	PercorrerArvore(RAIZ, "");

	cout << " Tabela contendo os caracteres e os codigos binarios" << endl;
	for(int i =0; i<TABELA.size(); i++){
		cout << TABELA[i].caractere<<" "<< TABELA[i].huff<< endl;
	}

	/*	Ler o arquivo original a partir do in�cio, e
	utilizando a �rvore de Huffman codificar
	cada byte salvando em um novo arquivo
	(com extens�o .HUF)
	*/

	fstream file("teste.txt",ios::in | ios::binary); // to read

	fstream ArquivoComprimido ("ArquivoComprimido.bin",ios::out | ios::binary); // to write

	char caractere;
	string letra;

	int count = 0;
	unsigned char saida = 0;

	while(file.read(&caractere,1))
	{
		letra = caractere;

		for(int i =0; i<TABELA.size(); i++){

			if(TABELA[i].caractere == letra){

				for(int j =0 ; j < TABELA[i].huff.length(); j++){

				if(TABELA[i].huff[j] == '1'){

					saida = saida << 1;
					saida = saida | 1;
					count ++;

				}
				else 
				{

					saida = saida << 1;
					count ++;
				}

				if(count == 8 ){

					ArquivoComprimido.put(saida);
					count = 0;

				}

				}
			}
		}
	}

	file.close();
	ArquivoComprimido.close();

}

