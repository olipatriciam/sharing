#pragma once

struct Compare : public binary_function<nodo*, nodo*, bool>
{
	bool operator()(nodo* x, nodo* y) const
	{
	 return (x->getFrequencia()) > (y->getFrequencia());
	}
};

struct transforma // esta sendo usada no vetor
{
	int frequencia;
	string caractere;
	string huff; // codigo huffman
};

class huffman
{
	priority_queue<nodo*,vector<nodo*>,Compare> Fila;

	map<string,int> tabela;

	vector<struct transforma> vetor;

	vector<struct transforma> TABELA; // essa eh a final

	nodo * RAIZ;

public:
	huffman(void);
	~huffman(void);

	void Calcular_Frequencia(); // ok
	void Create_binary_tree(); // ok
	void Create_new_file_HUF(); // extens�o .HUF
	void PercorrerArvore(nodo*, string);
};

