#include <iostream>
#include <string>



using namespace std;

#include "nodo.h"

nodo::nodo(void)
{
	frequencia = 0;
	simbol = '_';

	huffcode = ""; // fiz depois

	FilhoD = NULL;
	FilhoE = NULL;
}


nodo::~nodo(void)
{
}

int nodo::getFrequencia()
{
	return frequencia;
}
