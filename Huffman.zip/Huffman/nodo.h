#pragma once

#include <iostream>
#include <string>

using namespace std;

class nodo
{
	int frequencia;
	char simbol;

	string huffcode; // fiz depois

	nodo * FilhoD;
	nodo * FilhoE;

	friend class huffman;

public:
	nodo(void);
	~nodo(void);

	int getFrequencia();
};

