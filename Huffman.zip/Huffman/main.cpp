#include <algorithm>
#include <queue>
#include <deque>
#include <map>
#include <vector>
#include <fstream>
#include <iostream>
#include <string>

using namespace std;

#include"nodo.h"
#include "huffman.h"

void main()
{
	huffman * h = new huffman;

	h->Calcular_Frequencia();

	h->Create_binary_tree();

	h->Create_new_file_HUF();

	system("pause");
}